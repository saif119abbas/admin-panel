export class UserByTicket {
    constructor() {
        this.id = "1";
        this.name = "Saif";
        this.countryId = "UAE";
        this.mobileNumber = "0597335263";
        this.status = "Active";
    }
}