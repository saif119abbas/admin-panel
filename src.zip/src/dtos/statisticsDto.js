export class StatisticsDto {
    constructor() {
        this.totalNumberOfUsers = 0;
        this.totalNumberOfActiveUsers = 0;
        this.totalNumberOfPendingUsers = 0;
    }
}