export class UsersListDto {
    constructor() {
        this.id ="";
        this.firstName = "";
        this.lastName = "";
        this.country = "";
        this.city = "";
        this.countryName= "";
        this.cityName = "";
        this.email = "";
        this.birthdate = "";
        this.mobileNumber = "";
        this.role = "";
        this.image = "";
        this.status = 0;
    }
}