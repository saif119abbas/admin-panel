export class StatisticsDto {
    constructor() {
        this.totalNumberOfUsers = 50;
        this.totalNumberOfTicket = 50;
        this.totalTipAmount = 500;
        this.avgTipValue = 1;
    }
}