export class TipReceiverStatisticsDto {
    constructor() {
        this.totalReceivedAmount = 0;
        this.totalRequestedAmount = 0;

    }
}