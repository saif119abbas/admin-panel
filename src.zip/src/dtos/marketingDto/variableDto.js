/* eslint-disable no-template-curly-in-string */
export class VariableDto {
    constructor() {
        this.id = "222";
        this.name = "user_name";
    }
}