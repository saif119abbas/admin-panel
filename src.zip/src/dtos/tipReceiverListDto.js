export class TipReceiverListDto {
    constructor() {
        this.id ="1";
        this.name = "Saif Abbas";
        this.status = "Active";
        this.country = "Palestine";
        this.createdOn = "12/8/2024";
    }
}