export class TransactionsDto {
    constructor() {
        this.amount = 1200;
        this.balance = 6000;
        this.status = "pending";
        this.date = "10 May";
        this.time = "12 PM";
    }
}