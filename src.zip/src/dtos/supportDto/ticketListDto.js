export class TicketListDto {
    constructor() {
        this.id ="22";
        this.username = "Saif Abbas";
        this.subject = "App crashes";
        this.status = "state";
        this.dateSubmitted = "12/8/2024";
        this.lastUpdated = "12/8/2024";
    }
}