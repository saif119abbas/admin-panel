export class StatisticsDto {
    constructor() {
        this.totalNumberOfTickets = 20;
        this.totalNumberOfInProgressTickets = 4;
        this.totalNumberOfResolvedTickets= 10;
        this.totalNumberOfPendingTickets = 6;
    }
}