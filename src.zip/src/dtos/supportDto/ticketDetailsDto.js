export class TicketDetailsDto {
    constructor() {
        this.id="22"
        this.number = "Tick-123";
        this.createdOn = "12 July 2024, 4:00PM";
        this.resolvedOn = "--";
        this.statedBy = "Saif Abbas";
        this.issueType = "Tip Issue";
        this.status = "In Progress";
        this.message = "In Progress";
        
    }
}