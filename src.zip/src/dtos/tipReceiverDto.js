export class TipReceiverDto {
    constructor() {
        this.id = "1";
        this.firstName = "Saif";
        this.lastName = "Abbas";
        this.mobileNumber = "0597335263";
        this.status = "Active";
    }
}