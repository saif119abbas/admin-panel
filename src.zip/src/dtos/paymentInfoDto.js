export class PaymentInfoDto {
    constructor() {
        this.id = "11";
        this.accountHolderName = "Saif Abbas";
        this.IBAN = "4785566";
        this.bankName = "Test";
        this.countryId = "UAE";
    }
}